package jpaentities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-04-08T13:47:19.346-0700")
@StaticMetamodel(Optativa.class)
public class Optativa_ extends Asignatura_ {
	public static volatile SingularAttribute<Optativa, Integer> plazas;
	public static volatile SingularAttribute<Optativa, String> mencion;
}
