package jpaentities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Encuesta
 *
 */
@Entity @IdClass(Encuesta.EncuestaId.class)
public class Encuesta implements Serializable {
	
	
	public static class EncuestaId implements Serializable{
		private Integer fechaEnvio;
		private Integer expediente;
	}
	
	private static final long serialVersionUID = 1L;
	@Id @GeneratedValue(strategy= GenerationType.SEQUENCE)
	//@Column(name = "encuesta_fenvio")
	private Integer fechaEnvio;
	/*@ManyToMany
	@JoinTable(name = "jnd_enc_gpa", joinColumns = {@JoinColumn(name = "encuesta_fenvio"),@JoinColumn(name = "encuesta_exp")} ,inverseJoinColumns =  @JoinColumn(name= "grupos_por_asignatura_fk"))
	@JoinColumn (name = "grupos_por_asignatura_fk")
	private List<GruposPorAsignatura> grupos;*/
	@Id
	@ManyToOne
	//@JoinColumn(name = "encuesta_exp")
	private Expediente expediente;
	
	public Encuesta() {
		super();
	}

	public int getFechaEnvio() {
		return fechaEnvio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + fechaEnvio;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Encuesta other = (Encuesta) obj;
		if (fechaEnvio != other.fechaEnvio)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Encuesta [fechaEnvio=" + fechaEnvio + "]";
	}

}
