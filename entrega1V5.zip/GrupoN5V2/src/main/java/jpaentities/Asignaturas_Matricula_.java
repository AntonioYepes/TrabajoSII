package jpaentities;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-04-08T13:47:19.322-0700")
@StaticMetamodel(Asignaturas_Matricula.class)
public class Asignaturas_Matricula_ {
	public static volatile SingularAttribute<Asignaturas_Matricula, Asignatura> asignatura;
	public static volatile SingularAttribute<Asignaturas_Matricula, Matricula> matricula;
	public static volatile SingularAttribute<Asignaturas_Matricula, Grupo> grupo;
}
