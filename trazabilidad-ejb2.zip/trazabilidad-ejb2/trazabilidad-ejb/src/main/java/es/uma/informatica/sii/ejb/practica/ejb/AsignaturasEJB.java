package es.uma.informatica.sii.ejb.practica.ejb;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.management.RuntimeErrorException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import es.uma.informatica.sii.ejb.practica.ejb.exceptions.*;
import es.uma.informatica.sii.ejb.practica.entidades.*;

@Stateless
public class AsignaturasEJB {

	private static final Logger LOG = Logger.getLogger(GruposEJB.class.getCanonicalName());
	
	@PersistenceContext(name="Trazabilidad")
	private EntityManager em;
	
	public void insertar(Asignatura asignatura) throws CRUDException {
		if (asignatura == null) {
			throw new RuntimeErrorException(null, "Error a cambiar");
		}
			em.persist(asignatura);
	}
	
	public void eliminar(Asignatura asignatura) throws CRUDException {
		if (asignatura == null) {
			throw new RuntimeErrorException(null, "Error a cambiar");
		}
		Asignatura asignaturaEntity = em.find(Asignatura.class, asignatura.getReferencia());
		if (asignaturaEntity != null) {
			em.remove(asignaturaEntity);
		}
	}
	
	public void modificar(Asignatura asignatura) throws CRUDException {
		if (asignatura == null) {
			throw new RuntimeErrorException(null, "Error a cambiar");
		}
		Asignatura asignaturaEntity = em.find(Asignatura.class, asignatura.getReferencia());
		if (asignaturaEntity != null) {
			em.merge(asignatura);
		}
	}
	
	public Asignatura obtener(int id) throws CRUDException {
		Asignatura asignaturaEntity = em.find(Asignatura.class, id);
		return asignaturaEntity;
	}
	
	public List<Asignatura> obtenerGrupos() throws CRUDException {
		List<Asignatura> asignaturas = em.createQuery("Select * from Asignatura", Asignatura.class).getResultList();
		if (asignaturas == null) {
			throw new RuntimeErrorException(null, "Error a cambiar");
		}
		return asignaturas;
	}
	
	public List<Asignatura> asignaturasOfertadas() throws CRUDException {
		return em.createQuery("Select * from Asignatura Where Ofertada=TRUE", Asignatura.class).getResultList();
	}
	
	public void insertarArchivo() {
        Titulacion titul = new Titulacion();
        Asignatura asig = new Asignatura();
        Scanner sc = new Scanner(System.in);
        while(sc.hasNextLine()) {
            String aux = sc.nextLine();
            Scanner sc2 = new Scanner(aux);
            sc2.useDelimiter(";");
            while(sc2.hasNext()) {
                titul.setCodigo(sc2.nextInt());
                asig.setOfertada(sc2.nextBoolean());
                asig.setCodigo(sc2.nextInt());
                asig.setReferencia(sc2.nextInt());
                asig.setNombre(sc2.next());
                asig.setCurso(sc2.nextInt());
                asig.setCreditosT(sc2.nextInt());
                asig.setCreditosP(sc2.nextInt());
                asig.setDuracion(sc2.next());
                asig.setUnidadTemporal(sc2.next());
                asig.setIdiomasDeImparticion(sc2.next());
                asig.setTitulacion(titul);
                em.persist(asig);
            }
        }
    }
}
