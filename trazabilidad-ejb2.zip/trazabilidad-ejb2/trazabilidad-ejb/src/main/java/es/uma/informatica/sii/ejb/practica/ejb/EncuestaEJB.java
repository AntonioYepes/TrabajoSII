package es.uma.informatica.sii.ejb.practica.ejb;

import javax.management.RuntimeErrorException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import es.uma.informatica.sii.ejb.practica.ejb.exceptions.CRUDException;
import es.uma.informatica.sii.ejb.practica.entidades.Encuesta;

public class EncuestaEJB {
	@PersistenceContext(name="Trazabilidad")
	private EntityManager em;
	
	public void insertar(Encuesta encuesta) throws CRUDException {
        if (encuesta == null) {
            throw new RuntimeErrorException(null, "Error a cambiar");
        }
        Encuesta encuesta1 = em.find(Encuesta.class, encuesta);
        if (encuesta1 == null) {
            em.persist(encuesta);
        }
    }
    public void eliminar(Encuesta encuesta) throws CRUDException {
        if (encuesta == null) {
            throw new RuntimeErrorException(null, "Error a cambiar");
        }
        Encuesta encuesta1 = em.find(Encuesta.class, encuesta);
        if (encuesta1 != null) {
            em.remove(encuesta);
        }
    }
}
