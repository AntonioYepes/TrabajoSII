package es.uma.informatica.sii.ejb.practica.entidades;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2021-04-08T13:47:19.324-0700")
@StaticMetamodel(Encuesta.class)
public class Encuesta_ {
	public static volatile SingularAttribute<Encuesta, Integer> fechaEnvio;
	public static volatile SingularAttribute<Encuesta, Expediente> expediente;
}
