package es.uma.informatica.sii.ejb.practica.ejb.exceptions;

public class CRUDException extends Exception{
    public CRUDException() {
        super();
    }
    public CRUDException(String error) {
        super(error);
    }
}