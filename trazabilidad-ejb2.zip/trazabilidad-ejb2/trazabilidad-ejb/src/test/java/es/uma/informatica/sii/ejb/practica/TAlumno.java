package es.uma.informatica.sii.ejb.practica;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import es.uma.informatica.sii.ejb.practica.ejb.*;
import es.uma.informatica.sii.ejb.practica.ejb.exceptions.CRUDException;
import es.uma.informatica.sii.ejb.practica.entidades.Alumno;
import es.uma.informatica.sii.ejb.practica.entidades.Expediente;
import es.uma.informatica.sii.ejb.practica.entidades.Titulacion;

public class TAlumno {
	
	private static final Logger LOG = Logger.getLogger(TAlumno.class.getCanonicalName());

	private static final String ALUMNOS_EJB = "java:global/classes/AlumnosEJB";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "TrazabilidadTest";
	
	private AlumnosEJB alumnosEJB;
	
	@Before
	public void setup() throws NamingException  {
		alumnosEJB = (AlumnosEJB) SuiteTest.ctx.lookup(ALUMNOS_EJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
	
	@Test //@Requisito({"RF04"}) (Da error)
	public void testInsertarAlumno() {
		
		int dni = 21111111;
		int id = 0;
		try {
			Alumno al = new Alumno();
			al.setDNI(dni);
			al.setID(50);
			al.setNombreCompleto("Solomeo Paredes");
			al.setEmailInstitucional("solopar@uma.es");
			al.setEmailPersonal("meoparedes@gmail.com");
			al.setTelefono(600900600);
			al.setMovil(500200300);
			al.setDireccionNotificacion("micasa");
			al.setLocalidadNotificacion("mipueblo");
			al.setProvinciaNotificacion("mimalaguita");
			al.setCpNotificacion(29000);
			id = al.getID();
			
			
			try {
				alumnosEJB.insertar(al);
			} catch(Exception e) {
				fail("Excepción al insertar");
			}
		} catch(Exception e){
			fail("Excepción al crear alumno");
		}
		
		try {
			Alumno al = alumnosEJB.obtener(id);
			assertEquals("Solomeo Paredes", al.getNombreCompleto());
			assertEquals("solopar@uma.es", al.getEmailInstitucional());
			assertEquals("meoparedes@gmail.com", al.getEmailPersonal());
			assertTrue(600900600 == al.getTelefono());
			assertTrue(500200300 == al.getMovil());
			assertEquals("micasa", al.getDireccionNotificacion());
			assertEquals("mipueblo", al.getLocalidadNotificacion());
			assertEquals("mimalaguita", al.getProvinciaNotificacion());
			assertTrue(29000 == al.getCpNotificacion());
			
		} catch(Exception e) {
			fail("Excepción al comparar");
		}
	}
	
	@Test //@Requisito({"RF04"}) (Da error)
    public void testModificarAlumno() {
        try {
            Alumno al = alumnosEJB.obtener(88);
            al.setDNI(88888887);
            al.setMovil(952696969);
            al.setNombreCompleto("Mourinho Joseph");
            alumnosEJB.modificar(al);
            try {
            	assertTrue(88888887 == al.getDNI());
            	assertTrue(952696969 == al.getMovil());
            	assertEquals("Mourinho Joseph", al.getNombreCompleto());
            	
            }catch(Exception e) {
                fail("Modificacion Incorrecta");
            }
        } catch(CRUDException e) {
            fail("Alumno no encontrado");
        }
    }
	
	@Test //@Requisito({"RF04"}) (Da error)
    public void testEliminarAlumno() {

        Titulacion informatica = new Titulacion();
        informatica.setNombre("informatica");
        informatica.setCreditos(240);
        Expediente ex1 = new Expediente();
        ex1.setNumExpediente(1111);
        ex1.setCreditosSuperados(24);
        ex1.setNotaMediaProvisional(5.5);
        ex1.setTitulacion(informatica);
        ex1.setActivo(true);
        Alumno al1 = new Alumno();
        al1.setDNI(11111111);
        al1.setID(1);
        al1.setNombreCompleto("Gustavillo Pepinillo");
        al1.setExpedientes(Stream.of(ex1).collect(Collectors.toList()));
        int id=al1.getID();

        try {
            alumnosEJB.eliminar(al1);
            try {

                Alumno al2 = alumnosEJB.obtener(id);
                assertEquals(al2,null);

            }catch(CRUDException e) {
                fail("Alumno no eliminado");
            }

        } catch(CRUDException e) {
            fail("Alumno ya eliminado");
        }
    }
	
	@Test //@Requisito({"RF04"}) (Da error)
    public void testObtenerAlumno(){
		int Id = 10;
        int IdF = 4;
        try {
            Titulacion informatica = new Titulacion();
            informatica.setNombre("informatica");
            informatica.setCreditos(240);
            Expediente ex1 = new Expediente();
            ex1.setNumExpediente(1111);
            ex1.setCreditosSuperados(24);
            ex1.setNotaMediaProvisional(5.5);
            ex1.setTitulacion(informatica);
            ex1.setActivo(true);
            Alumno al1 = new Alumno();
            al1.setDNI(11111111);
            al1.setID(10);
            al1.setNombreCompleto("Gustavillo Pepinillo");
            al1.setExpedientes(Stream.of(ex1).collect(Collectors.toList()));
            
            Alumno al = alumnosEJB.obtener(Id);
            assertEquals(al, al1);
            
        } catch(CRUDException e) {
            fail("Alumno no encontrado");
        }
        try {
            Alumno alF = alumnosEJB.obtener(IdF);
            assertEquals(alF,null);
        }catch(CRUDException e) {
            fail("Alumno encontrado");
        }
	}
	
	@Test //@Requisito({"RF04"}) (Da error)
	public void testInsertarAlumnoCSV() {
		try {
			int numAlIniciales = alumnosEJB.cuentaAlumnos();;
			alumnosEJB.insertarDeArchivo();

			try {
				int numAl = alumnosEJB.cuentaAlumnos();
				//1508 + los que haya de antes.
				assertEquals(numAl-numAlIniciales, 1508 - numAlIniciales);

			}catch (Exception e) {
				fail("No es el mismo numero de alumnos");
			}
		}catch (Exception e) {
			fail("Fallo al insertar alumno");
		}
	}
}
