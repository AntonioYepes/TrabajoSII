package es.uma.informatica.sii.ejb.practica.entidades;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Solicitud
 *
 */
@Entity
public class Solicitud implements Serializable {
	@Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
	private String id_solicitud;
	private String destinatario;
	private String emisor;
	private String asunto;
	private String tipoSolicitud;
	
	@ManyToOne
	private Grupo grupo;
	@ManyToOne
	private Alumno alumno;
	
	private static final long serialVersionUID = 1L;

	public Solicitud() {
		super();
	}   
	public String getDestinatario() {
		return this.destinatario;
	}

	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}   
	public String getEmisor() {
		return this.emisor;
	}

	public void setEmisor(String emisor) {
		this.emisor = emisor;
	}   
	public String getAsunto() {
		return this.asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}   
	public String getTipoSolicitud() {
		return this.tipoSolicitud;
	}

	public void setTipoSolicitud(String tipoSolicitud) {
		this.tipoSolicitud = tipoSolicitud;
	}
   
}
