package es.uma.informatica.sii.ejb.practica.entidades;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Asignaturas_Matricula
 *
 */


@Entity
public class Asignaturas_Matricula implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Integer Id;
	
	@ManyToOne
    @JoinColumn(name="referencia")
    private Asignatura asignatura;

    @ManyToOne
    @JoinColumn(name="CursoAcademico")
    private Matricula matricula;

    @ManyToOne
    private Grupo grupo;
	
	
	public Asignaturas_Matricula() {
		super();
	}


	public Asignatura getAsignatura() {
		return asignatura;
	}


	public void setAsignatura(Asignatura asignatura) {
		this.asignatura = asignatura;
	}


	public Matricula getMatricula() {
		return matricula;
	}


	public void setMatricula(Matricula matricula) {
		this.matricula = matricula;
	}


	public Grupo getGrupo() {
		return grupo;
	}


	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}
	
   
}
