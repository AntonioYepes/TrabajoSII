package es.uma.informatica.sii.ejb.practica.ejb.exceptions;

public class TrazabilidadException extends Exception {
	
	public TrazabilidadException () {};
	
	public TrazabilidadException(String message) {
		super(message);
	}

}
