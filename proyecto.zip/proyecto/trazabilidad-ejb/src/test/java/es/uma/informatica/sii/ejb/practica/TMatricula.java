package es.uma.informatica.sii.ejb.practica;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import es.uma.informatica.sii.ejb.practica.ejb.*;
import es.uma.informatica.sii.ejb.practica.entidades.*;


public class TMatricula {
	
	private static final Logger LOG = Logger.getLogger(Matricula.class.getCanonicalName());

	private static final String MATRICULAEJB = "java:global/classes/matriculaEJB";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "TrazabilidadTest";
	
	private MatriculaEJB matriculaEJB;
	
	@Before
	public void setup() throws NamingException  {
		matriculaEJB = (MatriculaEJB) SuiteTest.ctx.lookup(MATRICULAEJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
	/*
	@Test //@Requisito({"RF05"}) (Da error)
	public void testInsertarAlumno() {
		int id = 0;
		try {
			Matricula mat = new Matricula();
            Expediente exp = new Expediente();
            mat.setID(exp, "primero");
            mat.setCursoAcademico("primero");
            mat.setEstado("Activo");
            mat.setNumeroArchivos(897987);
            mat.setExpediente(exp);
            matriculaEJB.modificar(mat);
			
			try {
				matriculaEJB.insertar(mat);
			} catch(Exception e) {
				fail("Excepción al insertar");
			}
		} catch(Exception e){
			fail("Excepción al crear matricula");
		}
		
		try {
			Matricula mat = matriculaEJB.obtener(id);
			assertEquals("primero", mat.getCursoAcademico());
			assertEquals("activo", mat.getEstado());
			assertTrue(897987 == mat.getNumeroArchivos());
			
		} catch(Exception e) {
			fail("Excepción al comparar");
		}
	}
	
	@Test //@Requisito({"RF05"}) (Da error)
    public void testModificarAlumno() throws CRUDException {
        try {
            Matricula mat = matriculaEJB.obtener(88888888);
            Expediente exp = new Expediente();
            mat.setID(exp, "primero");
            mat.setCursoAcademico("primero");
            mat.setEstado("Activo");
            mat.setNumeroArchivos(897987);
            mat.setExpediente(exp);
            matriculaEJB.modificar(mat);
            try {
                if(matriculaEJB.obtener(mat.getNumeroArchivos()) != mat) {
                    assertEquals(true,true);
                }
            }catch(CRUDException e) {
                fail("Modificacion Incorrecta");
            }
        } catch(CRUDException e) {
            fail("Matricula no encontrada");
        }
    }
	
	@Test //@Requisito({"RF05"}) (Da error)
    public void testEliminarAlumno() throws CRUDException {
		int id = 0;

		Matricula mat = matriculaEJB.obtener(88888888);
        Expediente exp = new Expediente();
        mat.setID(exp, "primero");
        mat.setCursoAcademico("primero");
        mat.setEstado("Activo");
        mat.setNumeroArchivos(897987);
        mat.setExpediente(exp);
        matriculaEJB.modificar(mat);

        try {
            matriculaEJB.eliminar(mat);
            try {

                Matricula mat2 = matriculaEJB.obtener(id);
                assertEquals(mat2,null);

            }catch(CRUDException e) {
                fail("Alumno no eliminado");
            }

        } catch(CRUDException e) {
            fail("Alumno ya eliminado");
        }
    }
	*/
}