package es.uma.informatica.sii.ejb.practica;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import es.uma.informatica.sii.ejb.practica.ejb.*;
import es.uma.informatica.sii.ejb.practica.entidades.*;


public class TAsignatura {
	
	private static final Logger LOG = Logger.getLogger(TAsignatura.class.getCanonicalName());

	private static final String ASIGNATURAS_EJB = "java:global/classes/AsignaturaEJB";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "TrazabilidadTest";
	
	private AsignaturasEJB asignaturasEJB;
	
	@Before
	public void setup() throws NamingException  {
		asignaturasEJB = (AsignaturasEJB) SuiteTest.ctx.lookup(ASIGNATURAS_EJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
	/*
	@Test //@Requisito({"RF03"}) (Da error)
    public void testInsertarAsignatura() {
		
		try {
			Asignatura a = new Asignatura();
			a.setReferencia(90);
			a.setCodigo(101);
			a.setCreditosT(6);
			a.setOfertada(true);
			a.setNombre("Calculo2");
			a.setCaracter("Obligatoria");
			a.setDuracion("4 meses");
			a.setUnidadTemporal("cuatrimestre");
			a.setIdiomasDeImparticion("español");
            try {
                asignaturasEJB.insertar(a);
            } catch(Exception e) {
                fail("Excepción al insertar");
            }
        } catch(Exception e){
            fail("Excepción al crear asignatura");
        }

        try {
            Asignatura a1 = asignaturasEJB.obtener(90);
            assertTrue(90 == a1.getReferencia());
            assertTrue(101 == a1.getCodigo());
            assertTrue(6 == a1.getCreditosT());
            assertEquals(true, a1.getOfertada());
            assertEquals("Calculo2", a1.getNombre());
            assertEquals("Obligatoria", a1.getCaracter());
            assertEquals("4 meses", a1.getDuracion());
            assertEquals("cuatrimestre", a1.getUnidadTemporal());
            assertEquals("español", a1.getIdiomasDeImparticion());
        } catch(Exception e) {
            fail("Excepción al comparar");
        }
    }
	@Test //@Requisito({"RF03"}) (Da error)
    public void testObtenerAsignatura(){
		int ref=10;
        Asignatura a1 = new Asignatura();
		a1.setReferencia(10);
		a1.setCodigo(101);
		a1.setCreditosT(6);
		a1.setOfertada(true);
		a1.setNombre("Calculo");
		a1.setCaracter("Obligatoria");
		a1.setDuracion("4 meses");
		a1.setUnidadTemporal("cuatrimestre");
		a1.setIdiomasDeImparticion("español");
		
        try {
            Asignatura a = asignaturasEJB.obtener(ref);
            assertEquals(a1, a);
            
        } catch(Exception e) {
            fail("Asignatura no encontrada");
        }
        try {
            Asignatura alF = asignaturasEJB.obtener(178);
            assertEquals(alF,null);
        }catch(Exception e) {
            fail("Asignatura encontrada");
        }
    }
	
	@Test //@Requisito({"RF03"}) (Da error)
    public void testEliminarAsignatura() throws TrazabilidadException {
        Asignatura calculo = new Asignatura();
		calculo.setReferencia(10);
		calculo.setCodigo(101);
		calculo.setCreditosT(6);
		calculo.setOfertada(true);
		calculo.setNombre("Calculo");
		calculo.setCaracter("Obligatoria");
		calculo.setDuracion("4 meses");
		calculo.setUnidadTemporal("cuatrimestre");
		calculo.setIdiomasDeImparticion("español");
		int ref = calculo.getReferencia();
        
        try {
            asignaturasEJB.eliminar(calculo);
            try {
                Asignatura a2 = asignaturasEJB.obtener(ref);
                assertEquals(a2, null);
            }catch(CRUDException e) {
                fail("Asignatura no eliminada");
            }
        } catch(CRUDException e) {
            fail("Error Asignatura");
        }
    }
 
	@Test //@Requisito({"RF03"}) (Da error)
	public void testModificarAsignatura() {
		int ref=10;
		Asignatura a1 = new Asignatura();
		a1.setReferencia(10);
		a1.setCreditosT(6);
		a1.setOfertada(true);
		a1.setNombre("Calculo");
		a1.setCaracter("Obligatoria");
		a1.setDuracion("4 meses");
		a1.setUnidadTemporal("cuatrimestre");
		a1.setIdiomasDeImparticion("ingles");
		
		try {
			Asignatura a2 = asignaturasEJB.obtener(ref);
			try {
				a2.setReferencia(102);
				asignaturasEJB.modificar(a1);
			}catch(Exception e){
				fail("Modificacion Incorrecta");
			}
		} catch(Exception e) {
			fail("No puede obtener asignatura");
		}
	}*/

}