package es.uma.informatica.sii.ejb.practica;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


import es.uma.informatica.sii.ejb.practica.ejb.*;
import es.uma.informatica.sii.ejb.practica.entidades.*;



public class TAlumno {
	
	private static final Logger LOG = Logger.getLogger(TAlumno.class.getCanonicalName());

	private static final String ALUMNO_EJB = "java:global/classes/AlumnoEJB";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "secretaria";
	
	private AlumnosEJB alumnoEJB;
	
	@Before
	public void setup() throws NamingException  {
		alumnoEJB = (AlumnosEJB) SuiteTest.ctx.lookup(ALUMNO_EJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
	
	@Test
	public void sillyTest() {
		fail("Not implemented yet");
	}
	/*
	@Test //@Requisito({"RF04"}) (Da error)
	public void testInsertarAlumno() {
		
		int dni = 21111111;
		int id = 0;
		try {
			Alumno al = new Alumno();
			al.setDNI(dni);
			al.setID(50);
			al.setNombreCompleto("Solomeo Paredes");
			al.setEmailInstitucional("solopar@uma.es");
			al.setEmailPersonal("meoparedes@gmail.com");
			al.setTelefono(600900600);
			al.setMovil(500200300);
			al.setDireccionNotificacion("micasa");
			al.setLocalidadNotificacion("mipueblo");
			al.setProvinciaNotificacion("mimalaguita");
			al.setCpNotificacion(29000);
			id = al.getID();
			
			
			try {
				alumnoEJB.insertar(al);
			} catch(Exception e) {
				fail("Excepción al insertar");
			}
		} catch(Exception e){
			fail("Excepción al crear alumno");
		}
		
		try {
			Alumno al = alumnoEJB.obtener(id);
			assertEquals("Solomeo Paredes", al.getNombreCompleto());
			assertEquals("solopar@uma.es", al.getEmailInstitucional());
			assertEquals("meoparedes@gmail.com", al.getEmailPersonal());
			assertTrue(600900600 == al.getTelefono());
			assertTrue(500200300 == al.getMovil());
			assertEquals("micasa", al.getDireccionNotificacion());
			assertEquals("mipueblo", al.getLocalidadNotificacion());
			assertEquals("mimalaguita", al.getProvinciaNotificacion());
			assertTrue(29000 == al.getCpNotificacion());
			
		} catch(Exception e) {
			fail("Excepción al comparar");
		}
	}
	
	@Test //@Requisito({"RF04"}) (Da error)
    public void testModificarAlumno() throws TrazabilidadException {
        try {
            Alumno al = alumnoEJB.obtener(88);
            al.setDNI(88888887);
            al.setMovil(952696969);
            al.setNombreCompleto("Mourinho Joseph");
            alumnoEJB.modificar(al);
            try {
            	assertTrue(88888887 == al.getDNI());
            	assertTrue(952696969 == al.getMovil());
            	assertEquals("Mourinho Joseph", al.getNombreCompleto());
            	
            }catch(Exception e) {
                fail("Modificacion Incorrecta");
            }
        } catch(CRUDException e) {
            fail("Alumno no encontrado");
        }
    }
	
	@Test //@Requisito({"RF04"}) (Da error)
    public void testEliminarAlumno() throws TrazabilidadException {

        Titulacion informatica = new Titulacion();
        informatica.setNombre("informatica");
        informatica.setCreditos(240);
        Expediente ex1 = new Expediente();
        ex1.setNumExpediente(1111);
        ex1.setCreditosSuperados(24);
        ex1.setNotaMediaProvisional(5.5);
        ex1.setTitulacion(informatica);
        ex1.setActivo(true);
        Alumno al1 = new Alumno();
        al1.setDNI(11111111);
        al1.setID(1);
        al1.setNombreCompleto("Gustavillo Pepinillo");
        al1.setExpedientes(Stream.of(ex1).collect(Collectors.toList()));
        int id=al1.getID();

        try {
            alumnoEJB.eliminar(al1);
            try {

                Alumno al2 = alumnoEJB.obtener(id);
                assertEquals(al2,null);

            }catch(CRUDException e) {
                fail("Alumno no eliminado");
            }

        } catch(CRUDException e) {
            fail("Alumno ya eliminado");
        }
    }
	/*
	@Test //@Requisito({"RF04"}) (Da error)
    public void testObtenerAlumno() throws TrazabilidadException{
		int Id = 10;
        int IdF = 4;
        try {
            Titulacion informatica = new Titulacion();
            informatica.setNombre("informatica");
            informatica.setCreditos(240);
            Expediente ex1 = new Expediente();
            ex1.setNumExpediente(1111);
            ex1.setCreditosSuperados(24);
            ex1.setNotaMediaProvisional(5.5);
            ex1.setTitulacion(informatica);
            ex1.setActivo(true);
            Alumno al1 = new Alumno();
            al1.setDNI(11111111);
            al1.setID(10);
            al1.setNombreCompleto("Gustavillo Pepinillo");
            al1.setExpedientes(Stream.of(ex1).collect(Collectors.toList()));
            
            Alumno al = alumnoEJB.obtener(Id);
            assertEquals(al, al1);
            
        } catch(CRUDException e) {
            fail("Alumno no encontrado");
        }
        try {
            Alumno alF = alumnoEJB.obtener(IdF);
            assertEquals(alF,null);
        }catch(CRUDException e) {
            fail("Alumno encontrado");
        }
	}
	
	@Test //@Requisito({"RF04"}) (Da error)
	public void testInsertarAlumnoCSV() {
		File file = new File("alumnos.csv");
		try {
			int numAlIniciales = alumnoEJB.cuentaAlumnos();;
			alumnoEJB.insertarDeArchivo(file);

			try {
				int numAl = alumnoEJB.cuentaAlumnos();
				//1508 + los que haya de antes.
				assertEquals(numAl-numAlIniciales, 1508 - numAlIniciales);

			}catch (Exception e) {
				fail("No es el mismo numero de alumnos");
			}
		}catch (Exception e) {
			fail("Fallo al insertar alumno");
		}
	}
	*/
}