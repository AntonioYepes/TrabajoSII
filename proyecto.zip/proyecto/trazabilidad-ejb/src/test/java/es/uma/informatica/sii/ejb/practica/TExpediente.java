package es.uma.informatica.sii.ejb.practica;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import es.uma.informatica.sii.ejb.practica.ejb.*;
import es.uma.informatica.sii.ejb.practica.entidades.*;



public class TExpediente {
	
	private static final Logger LOG = Logger.getLogger(TExpediente.class.getCanonicalName());

	private static final String EXPEDIENTE_EJB = "java:global/classes/ExpedienteEJB";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "TrazabilidadTest";
	
	private ExpedienteEJB expedienteEJB;
	
	@Before
	public void setup() throws NamingException  {
		expedienteEJB = (ExpedienteEJB) SuiteTest.ctx.lookup(EXPEDIENTE_EJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
	/*
	@Test //@Requisito({"RF06"}) (Da error)
    public void testInsertarExpediente() {
		Titulacion informatica = new Titulacion();
		informatica.setNombre("informatica");
		informatica.setCreditos(240);
		Expediente a = new Expediente();
		a.setNumExpediente(1111);
		a.setCreditosSuperados(24);
		a.setNotaMediaProvisional(5.5);
		a.setTitulacion(informatica);
		a.setActivo(true);
		try {
            try {
                expedienteEJB.insertar(a);
            } catch(Exception e) {
                fail("Excepción al insertar");
            }
        } catch(Exception e){
            fail("Excepción al crear asignatura");
        }

        try {
            Expediente a1 = expedienteEJB.obtener(1111);
            assertTrue(1111 == a1.getNumExpediente());
            assertTrue(5.5 == a1.getNotaMediaProvisional());
            assertEquals(informatica, a1.getTitulacion());
            assertEquals(true, a1.isActivo());
        } catch(Exception e) {
            fail("Excepción al comparar");
        }
    }
	@Test //@Requisito({"RF06"}) (Da error)
    public void testObtenerExpediente(){
		int numExp = 1111;
		int numExpF = 999999;
		Titulacion informatica = new Titulacion();
		informatica.setNombre("informatica");
		informatica.setCreditos(240);
		Expediente a = new Expediente();
		a.setNumExpediente(1111);
		a.setCreditosSuperados(24);
		a.setNotaMediaProvisional(5.5);
		a.setTitulacion(informatica);
		a.setActivo(true);
        try {
            Expediente a1 = expedienteEJB.obtener(numExp);
            boolean compare=a1.equals(a);
            if(!compare) {
                throw new CRUDException("Expediente no esta en BD pero deberia");
            }
            
        } catch(Exception e) {
            fail("Expediente no encontrado");
        }
        try {
        	Expediente eF = expedienteEJB.obtener(numExpF);
            assertEquals(eF,null);
        }catch(Exception e) {
            fail("Expediente encontrado");
        }
    }
	
	@Test //@Requisito({"RF06"}) (Da error)
    public void testEliminarExpediente() {
		int numExp = 1111;
		Titulacion informatica = new Titulacion();
		informatica.setNombre("informatica");
		informatica.setCreditos(240);
		Expediente a = new Expediente();
		a.setNumExpediente(1111);
		a.setCreditosSuperados(24);
		a.setNotaMediaProvisional(5.5);
		a.setTitulacion(informatica);
		a.setActivo(true);
        try {
            expedienteEJB.eliminar(a);
            try {
                Expediente a2 = expedienteEJB.obtener(numExp);
                assertEquals(a2, null);
            }catch(CRUDException e) {
                fail("Asignatura no eliminada");
            }
        } catch(CRUDException e) {
            fail("Error Asignatura");
        }
    }
 
	@Test //@Requisito({"RF06"}) (Da error)
	public void testModificarAsignatura() {
		int numExp = 1111;
		Titulacion informatica = new Titulacion();
		informatica.setNombre("informatica");
		informatica.setCreditos(240);
		Expediente a = new Expediente();
		a.setNumExpediente(1111);
		a.setCreditosSuperados(24);
		a.setNotaMediaProvisional(5.5);
		a.setTitulacion(informatica);
		a.setActivo(true);
		try {
			Expediente a2 = expedienteEJB.obtener(numExp);
			try {
				a2.setNumExpediente(102);
				expedienteEJB.modificar(a);
			}catch(Exception e){
				fail("Modificacion Incorrecta");
			}
		} catch(Exception e) {
			fail("No puede obtener asignatura");
		}
	}*/

}