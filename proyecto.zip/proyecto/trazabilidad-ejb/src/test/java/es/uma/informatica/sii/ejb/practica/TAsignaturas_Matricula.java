package es.uma.informatica.sii.ejb.practica;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ejb.embeddable.EJBContainer;
import javax.naming.Context;
import javax.naming.NamingException;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import es.uma.informatica.sii.ejb.practica.ejb.*;
import es.uma.informatica.sii.ejb.practica.entidades.*;


public class TAsignaturas_Matricula {
	
	private static final Logger LOG = Logger.getLogger(TAsignaturas_Matricula.class.getCanonicalName());

	private static final String ASIGNATURAS_MATRICULAEJB = "java:global/classes/Asignaturas_matriculaEJB";
	private static final String UNIDAD_PERSITENCIA_PRUEBAS = "TrazabilidadTest";
	
	private Asignaturas_MatriculaEJB amatriculaEJB;
	
	@Before
	public void setup() throws NamingException  {
		amatriculaEJB = (Asignaturas_MatriculaEJB) SuiteTest.ctx.lookup(ASIGNATURAS_MATRICULAEJB);
		BaseDatos.inicializaBaseDatos(UNIDAD_PERSITENCIA_PRUEBAS);
	}
/*
	@Test //@Requisito({"RF01, RF07"}) (Da error)
	public void testCambiarGrupo() {
		 Matricula mat = new Matricula();
	        mat.setEstado("Activa");
	        mat.setNumeroArchivos(1);
	        mat.setTurnoPreferencia("MaÃ±ana");
	        mat.setFechaMatricula("10/06/2020");
	        mat.setNuevoIngreso(true);
	        mat.setListaAsignaturas("");
	        mat.setGrupos("101, 102, 103, 104");
		try {
			String gruposIniciales = mat.getGrupos();
			
			try {
				amatriculaEJB.cambiarGrupo(mat, "103", "105");
				assertEquals("101, 102, 105, 104", mat.getGrupos());
				
			}catch (Exception e) {
				fail("No es el mismo listado de grupos");
			}
				}catch (Exception e) {
					fail("Fallo al insertar grupo");
				}
	}*/
}