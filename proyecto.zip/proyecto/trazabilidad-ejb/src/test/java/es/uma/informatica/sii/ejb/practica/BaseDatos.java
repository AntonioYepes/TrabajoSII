package es.uma.informatica.sii.ejb.practica;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import es.uma.informatica.sii.*;
import es.uma.informatica.sii.ejb.practica.entidades.*;


public class BaseDatos {
	public static void inicializaBaseDatos(String nombreUnidadPersistencia) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(nombreUnidadPersistencia);
		EntityManager em = emf.createEntityManager();
		
		em.getTransaction().begin();
		
		/*====================
		 * CENTRO
		 * ===================*/
		Centro etsii = new Centro();
		etsii.setNombre("etsii");
		etsii.setDireccion("Malaga");
		etsii.setTelefonoConsejeria(952000000);
		em.persist(etsii);
		
		/*====================
		 * TITULACIONES
		 * ===================*/
		Titulacion informatica = new Titulacion();
		informatica.setNombre("informatica");
		informatica.setCreditos(240);
		em.persist(informatica);
		
		Titulacion computadores = new Titulacion();
		computadores.setNombre("computadores");
		computadores.setCreditos(240);
		em.persist(computadores);
		
		Titulacion software = new Titulacion();
		software.setNombre("software");
		software.setCreditos(240);
		em.persist(software);
		
		//Relacion de centro y titulaciones
		etsii.setTitulaciones(Stream.of(informatica, computadores, software).collect(Collectors.toList()));
		
		/*====================
		 * ASIGNATURAS
		 * ===================*/
		Asignatura calculo = new Asignatura();
		calculo.setReferencia(10);
		calculo.setCodigo(101);
		calculo.setCreditos(6);
		calculo.setOfertada(true);
		calculo.setNombre("Calculo");
		calculo.setCaracter("Obligatoria");
		calculo.setDuracion("4 meses");
		calculo.setUnidadTemporal("cuatrimestre");
		calculo.setIdiomasDeImparticion("español");
		em.persist(calculo);
		
		Asignatura discreta = new Asignatura();
		discreta.setReferencia(20);
		discreta.setCodigo(102);
		discreta.setCreditos(6);
		discreta.setOfertada(true);
		discreta.setNombre("Discreta");
		discreta.setCaracter("Obligatoria");
		discreta.setDuracion("4 meses");
		discreta.setUnidadTemporal("cuatrimestre");
		discreta.setIdiomasDeImparticion("español");
		em.persist(discreta);
		
		Asignatura estadistica = new Asignatura();
		estadistica.setReferencia(30);
		estadistica.setCodigo(103);
		estadistica.setCreditos(6);
		estadistica.setOfertada(true);
		estadistica.setNombre("Estadistica");
		estadistica.setCaracter("Obligatoria");
		estadistica.setDuracion("4 meses");
		estadistica.setUnidadTemporal("cuatrimestre");
		estadistica.setIdiomasDeImparticion("español");
		em.persist(estadistica);
		
		Asignatura programacion = new Asignatura();
		programacion.setReferencia(40);
		programacion.setCodigo(104);
		programacion.setCreditos(6);
		programacion.setOfertada(true);
		programacion.setNombre("Programacion");
		programacion.setCaracter("Obligatoria");
		programacion.setDuracion("4 meses");
		programacion.setUnidadTemporal("cuatrimestre");
		programacion.setIdiomasDeImparticion("español");
		em.persist(programacion);
		
		Asignatura fisica = new Asignatura();
		fisica.setReferencia(50);
		fisica.setCodigo(105);
		fisica.setCreditos(6);
		fisica.setOfertada(true);
		fisica.setNombre("Fisica");
		fisica.setCaracter("Obligatoria");
		fisica.setDuracion("4 meses");
		fisica.setUnidadTemporal("cuatrimestre");
		fisica.setIdiomasDeImparticion("español");
		em.persist(fisica);
		
		/*====================
		 * GRUPOS
		 * ===================*/
		Grupo A = new Grupo();
		A.setCurso("Primero");
		A.setLetra("A");
		A.setTurno("Mañana");
		A.setIngles(false);
		A.setVisible(true);
		A.setAsignar("???");
		A.setPlazas(50);
		em.persist(A);
		
		Grupo B = new Grupo();
		B.setCurso("Primero");
		B.setLetra("B");
		B.setTurno("Mañana");
		B.setIngles(false);
		B.setVisible(true);
		B.setAsignar("???");
		B.setPlazas(50);
		em.persist(B);
		
		Grupo C = new Grupo();
		C.setCurso("Primero");
		C.setLetra("C");
		C.setTurno("Mañana");
		C.setIngles(false);
		C.setVisible(true);
		C.setAsignar("???");
		C.setPlazas(50);
		em.persist(C);
		
		/*====================
		 * GRUPOS ASIG
		 * ===================*/
		GruposPorAsignatura calcA = new GruposPorAsignatura();
		calcA.setOferta(true);
		calcA.setAsignatura(calculo);
		calcA.setGrupo(A);
		em.persist(calcA);
		
		GruposPorAsignatura calcB = new GruposPorAsignatura();
		calcB.setOferta(true);
		calcB.setAsignatura(calculo);
		calcB.setGrupo(B);
		em.persist(calcB);
		
		GruposPorAsignatura MDiscretasA = new GruposPorAsignatura();
        MDiscretasA.setOferta(true);
        MDiscretasA.setAsignatura(discreta);
        MDiscretasA.setGrupo(A);
        em.persist(MDiscretasA);

        GruposPorAsignatura MDiscretasB = new GruposPorAsignatura();
        MDiscretasB.setOferta(true);
        MDiscretasB.setAsignatura(discreta);
        MDiscretasB.setGrupo(B);
        em.persist(MDiscretasB);
        
        GruposPorAsignatura estadisticasA = new GruposPorAsignatura();
        estadisticasA.setOferta(true);
        estadisticasA.setAsignatura(estadistica);
        estadisticasA.setGrupo(A);
        em.persist(estadisticasA);

        GruposPorAsignatura estadisticasB = new GruposPorAsignatura();
        estadisticasB.setOferta(true);
        estadisticasB.setAsignatura(estadistica);
        estadisticasB.setGrupo(B);
        em.persist(estadisticasB);

        GruposPorAsignatura programacionA = new GruposPorAsignatura();
        programacionA.setOferta(true);
        programacionA.setAsignatura(programacion);
        programacionA.setGrupo(A);
        em.persist(programacionA);
        
        GruposPorAsignatura programacionB = new GruposPorAsignatura();
        programacionB.setOferta(true);
        programacionB.setAsignatura(programacion);
        programacionB.setGrupo(B);
        em.persist(programacionB);

        GruposPorAsignatura fisicaA = new GruposPorAsignatura();
        fisicaA.setOferta(true);
        fisicaA.setAsignatura(fisica);
        fisicaA.setGrupo(A);
        em.persist(fisicaA);

        GruposPorAsignatura fisicaB = new GruposPorAsignatura();
        fisicaB.setOferta(true);
        fisicaB.setAsignatura(fisica);
        fisicaB.setGrupo(B);
        em.persist(fisicaB);
        
        /*====================
		 * CLASES
		 * ===================*/
//        Clase DiscretaA= new Clase();
//		DiscretaA.setDia("12/03/2021");
//		DiscretaA.setHoraInicio("08:45");
//		DiscretaA.setHoraFin("10:30");
//		DiscretaA.setAsignatura(discreta);
//		DiscretaA.setGrupo(A);
//		em.persist(DiscretaA);
//		
//		Clase DiscretaB= new Clase();
//		DiscretaB.setDia("12/03/2021");
//		DiscretaB.setHoraInicio("08:45");
//		DiscretaB.setHoraFin("10:30");
//		DiscretaB.setAsignatura(discreta);
//		DiscretaB.setGrupo(B);
//		em.persist(DiscretaB);
//		
//		Clase CalculoA= new Clase();
//		CalculoA.setDia("12/03/2021");
//		CalculoA.setHoraInicio("10:45");
//		CalculoA.setHoraFin("12:30");
//		CalculoA.setAsignatura(calculo);
//		CalculoA.setGrupo(A);
//		em.persist(CalculoA);
//		
//		Clase CalculoB= new Clase();
//		CalculoB.setDia("16/03/2021");
//		CalculoB.setHoraInicio("10:45");
//		CalculoB.setHoraFin("12:30");
//		CalculoB.setAsignatura(calculo);
//		CalculoB.setGrupo(B);
//		em.persist(CalculoB);
        
        /*====================
		 * EXPEDIENTES
		 * ===================*/
		Expediente ex1 = new Expediente();
		ex1.setNumExpediente(1111);
		ex1.setCreditosSuperados(24);
		ex1.setNotaMediaProvisional(5.5);
		ex1.setTitulacion(informatica);
		ex1.setActivo(true);
		em.persist(ex1);
		em.persist(ex1);
		
		Expediente ex2 = new Expediente();
		ex2.setNumExpediente(2222);
		ex2.setCreditosSuperados(12);
		ex2.setNotaMediaProvisional(5);
		ex2.setTitulacion(informatica);
		ex2.setActivo(true);
		em.persist(ex2);
		
		Expediente ex3 = new Expediente();
		ex3.setNumExpediente(3333);
		ex3.setCreditosSuperados(60);
		ex3.setNotaMediaProvisional(6.5);
		ex3.setTitulacion(computadores);
		ex3.setActivo(true);
		em.persist(ex3);
		
		Expediente ex4 = new Expediente();
		ex4.setNumExpediente(4444);
		ex4.setCreditosSuperados(36);
		ex4.setNotaMediaProvisional(7.6);
		ex4.setTitulacion(computadores);
		ex4.setActivo(true);
		em.persist(ex4);
		
		Expediente ex5 = new Expediente();
		ex5.setNumExpediente(5555);
		ex5.setCreditosSuperados(120);
		ex5.setNotaMediaProvisional(7.6);
		ex5.setTitulacion(software);
		ex5.setActivo(true);
		em.persist(ex5);
		
		Expediente ex6 = new Expediente();
		ex6.setNumExpediente(6666);
		ex6.setCreditosSuperados(36);
		ex6.setNotaMediaProvisional(7.0);
		ex6.setTitulacion(software);
		ex6.setActivo(true);
		em.persist(ex6);
		
		Expediente ex7 = new Expediente();
		ex7.setNumExpediente(7777);
		ex7.setCreditosSuperados(66);
		ex7.setNotaMediaProvisional(7.8);
		ex7.setTitulacion(computadores);
		ex7.setActivo(true);
		em.persist(ex7);
		
		Expediente ex8 = new Expediente();
		ex8.setNumExpediente(8888);
		ex8.setCreditosSuperados(42);
		ex8.setNotaMediaProvisional(7.4);
		ex8.setTitulacion(informatica);
		ex8.setActivo(true);
		em.persist(ex8);
		
		Expediente ex9 = new Expediente();
		ex9.setNumExpediente(9999);
		ex9.setCreditosSuperados(48);
		ex9.setNotaMediaProvisional(6.7);
		ex9.setTitulacion(informatica);
		ex9.setActivo(true);
		em.persist(ex9);
		
		Expediente ex10 = new Expediente();
		ex10.setNumExpediente(1010);
		ex10.setCreditosSuperados(18);
		ex10.setNotaMediaProvisional(7.4);
		ex10.setTitulacion(software);
		ex10.setActivo(true);
		em.persist(ex10);
		
		/*====================
		 * MATRICULAS
		 * ===================*/
        Matricula mat1 = new Matricula();
        mat1.setEstado("Activa");
        mat1.setNumeroArchivos(1);
        mat1.setTurnoPreferencia("Mañana");
        mat1.setFechaMatricula("10/06/2020");
        mat1.setNuevoIngreso(true);
        mat1.setListaAsignaturas("");
        mat1.setExpediente(ex1);
        em.persist(mat1);
        
        Matricula mat2 = new Matricula();
        mat2.setEstado("Activa");
        mat2.setNumeroArchivos(1);
        mat2.setTurnoPreferencia("Mañana");
        mat2.setFechaMatricula("17/06/2020");
        mat2.setNuevoIngreso(true);
        mat2.setListaAsignaturas("");
        mat2.setExpediente(ex2);
        em.persist(mat2);
        
        Matricula mat3 = new Matricula();
        mat3.setEstado("Activa");
        mat3.setNumeroArchivos(1);
        mat3.setTurnoPreferencia("Mañana");
        mat3.setFechaMatricula("23/06/2020");
        mat3.setNuevoIngreso(true);
        mat3.setListaAsignaturas("");
        mat3.setExpediente(ex3);
        em.persist(mat3);
        
        Matricula mat4 = new Matricula();
        mat4.setEstado("Activa");
        mat4.setNumeroArchivos(1);
        mat4.setTurnoPreferencia("Mañana");
        mat4.setFechaMatricula("21/09/2020");
        mat4.setNuevoIngreso(true);
        mat4.setListaAsignaturas("");
        mat4.setExpediente(ex4);
        em.persist(mat4);
        
        Matricula mat5 = new Matricula();
        mat5.setEstado("Activa");
        mat5.setNumeroArchivos(1);
        mat5.setTurnoPreferencia("Mañana");
        mat5.setFechaMatricula("10/06/2020");
        mat5.setNuevoIngreso(true);
        mat5.setListaAsignaturas("");
        mat5.setExpediente(ex5);
        em.persist(mat5);
        
        Matricula mat6 = new Matricula();
        mat6.setEstado("Activa");
        mat6.setNumeroArchivos(1);
        mat6.setTurnoPreferencia("Mañana");
        mat6.setFechaMatricula("10/06/2020");
        mat6.setNuevoIngreso(true);
        mat6.setListaAsignaturas("");
        mat6.setExpediente(ex6);
        em.persist(mat6);
        
        Matricula mat7 = new Matricula();
        mat7.setEstado("Activa");
        mat7.setNumeroArchivos(1);
        mat7.setTurnoPreferencia("Mañana");
        mat7.setFechaMatricula("10/06/2020");
        mat7.setNuevoIngreso(true);
        mat7.setListaAsignaturas("");
        mat7.setExpediente(ex7);
        em.persist(mat7);
        
        Matricula mat8 = new Matricula();
        mat8.setEstado("Activa");
        mat8.setNumeroArchivos(1);
        mat8.setTurnoPreferencia("Mañana");
        mat8.setFechaMatricula("10/06/2020");
        mat8.setNuevoIngreso(true);
        mat8.setListaAsignaturas("");
        mat8.setExpediente(ex8);
        em.persist(mat8);
        
        Matricula mat9 = new Matricula();
        mat9.setEstado("Activa");
        mat9.setNumeroArchivos(1);
        mat9.setTurnoPreferencia("Mañana");
        mat9.setFechaMatricula("10/06/2020");
        mat9.setNuevoIngreso(true);
        mat9.setListaAsignaturas("");
        mat9.setExpediente(ex9);
        em.persist(mat9);
        
        Matricula mat10 = new Matricula();
        mat10.setEstado("Activa");
        mat10.setNumeroArchivos(1);
        mat10.setTurnoPreferencia("Mañana");
        mat10.setFechaMatricula("10/06/2020");
        mat10.setNuevoIngreso(true);
        mat10.setListaAsignaturas("");
        mat10.setExpediente(ex10);
        em.persist(mat10);
		
		/*====================
		 * ALUMNOS
		 * ===================*/
        Alumno al1 = new Alumno();
		al1.setID(10);
		al1.setDNI(11111111);
		al1.setNombreCompleto("Gustavillo Pepinillo");
		al1.setExpedientes(Stream.of(ex1).collect(Collectors.toList()));
		em.persist(al1);
		
		Alumno al2 = new Alumno();
		al2.setDNI(22222222);
		al2.setNombreCompleto("Angelo Balotelli");
		al2.setExpedientes(Stream.of(ex2).collect(Collectors.toList()));
		em.persist(al2);
		
		Alumno al3 = new Alumno();
		al3.setDNI(33333333);
		al3.setNombreCompleto("Cristiano Messi");
		al1.setExpedientes(Stream.of(ex3).collect(Collectors.toList()));
		em.persist(al3);
		
		Alumno al4 = new Alumno();
		al4.setDNI(44444444);
		al4.setNombreCompleto("Dixon Gauss");
		al4.setExpedientes(Stream.of(ex4).collect(Collectors.toList()));
		em.persist(al4);
		
		Alumno al5 = new Alumno();
		al5.setDNI(55555555);
		al5.setNombreCompleto("Xokas Retriever");
		al5.setExpedientes(Stream.of(ex5).collect(Collectors.toList()));
		em.persist(al5);
		
		Alumno al6 = new Alumno();
		al6.setDNI(66666666);
		al6.setNombreCompleto("Marbello Vicios");
		al6.setExpedientes(Stream.of(ex6).collect(Collectors.toList()));
		em.persist(al6);
		
		Alumno al7 = new Alumno();
		al7.setDNI(7777777);
		al7.setNombreCompleto("Pep Peregrino");
		al7.setExpedientes(Stream.of(ex7).collect(Collectors.toList()));
		em.persist(al7);
		
		Alumno al8 = new Alumno();
		al8.setID(88);
		al8.setDNI(88888888);
		al8.setNombreCompleto("Mourinho Magno");
		al8.setExpedientes(Stream.of(ex8).collect(Collectors.toList()));
		em.persist(al8);
		
		Alumno al9 = new Alumno();
		al9.setDNI(99999999);
		al9.setNombreCompleto("Quintana Xin");
		al9.setExpedientes(Stream.of(ex9).collect(Collectors.toList()));
		em.persist(al9);
		
		Alumno al10 = new Alumno();
		al10.setDNI(10101010);
		al10.setNombreCompleto("Nacho Zhao");
		al10.setExpedientes(Stream.of(ex10).collect(Collectors.toList()));
		em.persist(al10);
		
		/*====================
		 * ASIG MATRICULA
		 * ===================*/
//		Asignaturas_Matricula asmat1 = new Asignaturas_Matricula();
//		asmat1.setMatricula(mat1);
//		em.persist(asmat1);
		//Echarle un ojo a asignaturas matricula
		
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	}
}
