package jpaentities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Asignaturas_Matricula
 *
 */



@Entity @IdClass(value = Asignaturas_MatriculaId.class)
public class Asignaturas_Matricula implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id private Integer referencia;
	@Id private String Curso_Academico;
	
	@ManyToOne
	private Asignatura asignatura;
	@ManyToOne
	private Matricula matricula;
	@ManyToOne
	private Grupo grupo;
	
	
	public Asignaturas_Matricula() {
		super();
	}
   
}
