package jpaentities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Asignaturas_Matricula
 *
 */


@Entity @IdClass(Asignaturas_Matricula.Asignaturas_MatriculaId.class)
public class Asignaturas_Matricula implements Serializable {
	
	public static class Asignaturas_MatriculaId implements Serializable {
		private static final long serialVersionUID = 1L;
		private Integer referencia;
		private String Curso_Academico;
	}
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@ManyToOne
	private Asignatura asignatura;
	@Id
	@ManyToOne
	private Matricula matricula;
	@ManyToOne
	private Grupo grupo;
	
	
	public Asignaturas_Matricula() {
		super();
	}
   
}
